package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Dbutil.Dbutil;
import User.user;

public class Daoclass {
    Dbutil d1 = new Dbutil();
    
   public  static int insertdata( user u) throws ClassNotFoundException, SQLException
              
   {
   	int status =0;
      Connection gs = Dbutil.getconnection();
   PreparedStatement ps = gs.prepareStatement("insert into userdetails values( ?,? , ? ,? )"); 
   	    ps.setString(1, u.getId());
           ps.setString(2, u.getUsername());
   	    ps.setString(3, u.getPassword());
   	    ps.setString(4, u.getUsertype());
   	    status = ps.executeUpdate(); 
		return status;
   	
   }
}
