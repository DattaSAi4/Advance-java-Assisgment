package Dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dbutil {
	public static Connection getconnection() throws ClassNotFoundException, SQLException
	{
		Connection conn = null;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/course" ,"root" ,"root");
		return conn;
		
	}
	public static void closeconnection(Connection con) throws SQLException
	{
	    con.close();
	}
}
