package Abstract_Class_and_Interface32;

public class Testmedicine {
	
	public static void main(String[] args)
	{
	    

	    medicoinfo m[] = new medicoinfo[10]; 
	    double i = Math.random()*4;

	    int j = (int) i;

	    System.out.println(j);

	    switch(j){

	    case 1: 
	    		m[1] = new tablets();
	    		m[1].displaydetails();
	    break;

	    case 2: 
	    		m[2] = new Syrup();
	    		m[2].displaydetails();
	    break;

	    case 3: 
	    		m[3] = new ointment();
	    		m[3].displaydetails();
	    break;

	    default: System.out.println("Invalid Choice");

	    }
	          
	}

}
