package Abstract_Class_and_Interface32;

public interface medicoinfo {
	
        abstract void displaydetails();
}



