package Abstract_Class_and_Interface32;

public class Syrup implements medicoinfo {

	@Override
	public void displaydetails() {
		System.out.println("It should be store in below -30c");
		
	}

}
