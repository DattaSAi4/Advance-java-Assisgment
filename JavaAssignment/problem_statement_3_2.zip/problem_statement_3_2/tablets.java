package Abstract_Class_and_Interface32;

public class tablets implements medicoinfo {

	@Override
	public void displaydetails() {
		System.out.println("It Should be store in a cold place");
	}
	
}
