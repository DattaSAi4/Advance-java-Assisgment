package problem_statement_6_1;

import java.util.ArrayList;

public class Add_a_Students {
	
	public static void main(String[] args)
	{
	        ArrayList s1 = new ArrayList<String>();
	        s1.add("vinay");
	        s1.add("Sai");
	        s1.add("Datta");
	        System.out.println(s1);
	        
	        if(s1.contains("vinay"))
	        {
	        	System.out.println("welcome dude");
	        }
	        else
	        {
	        	System.out.println("wrong contact");
	        }
	        
	}

}
