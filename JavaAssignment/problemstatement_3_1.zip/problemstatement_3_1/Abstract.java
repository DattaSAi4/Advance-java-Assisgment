package Abstract_Class_and_Interface3;

abstract class instrument{
	 
	 abstract void play();
	 
	 public  static class piano extends instrument
	 {
		@Override
		void play() {
			System.out.println("Piano is playing tan tan tan tan");
			
		}
		public class flute extends instrument
		{

			@Override
			void play() {
				System.out.println("Flute is playing toot toot toot too");
				
			}
		}
		public class guitar extends instrument
		{

			@Override
			void play() {
				System.out.println("Guitar is playing tin tin tin");
				
			}
			
		}
		
	 }
	 {

			Instrument A[] = new Instrument[12];



			for (int iLoop=0; iLoop<12; iLoop++)

			{

			switch (iLoop%3)

			{

			case 0: { A[iLoop] = new Piano(); break; }

			case 1: { A[iLoop] = new Flute(); break; }

			case 2: { A[iLoop] = new Guitar(); break; }

			}

			}



			for (int iLoop=0; iLoop<12; iLoop++)

			{

			System.out.println("------------------------------------");

			System.out.println(" object # " + (iLoop+1));

			A[iLoop].Play();

			if (A[iLoop] instanceof Piano) { System.out.println("Piano"); }

			if (A[iLoop] instanceof Flute) { System.out.println("Flute"); }

			if (A[iLoop] instanceof Guitar) { System.out.println("Guitar"); }



			}



			}



			}

 
 			
 
 
 
 
