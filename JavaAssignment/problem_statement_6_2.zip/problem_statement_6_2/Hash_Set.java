package problem_statement_6_2;

import java.util.Hashtable;
import java.util.Scanner;

public class Hash_Set {
	
	/*public static void main(String[] args)
	{
	Hashtable<String, String> h1 = new Hashtable<String, String>();
	Scanner s1 = new Scanner(System.in);
	System.out.println("enter the product id and product name");
	for(int i=0;i<2;i++)
	{
		h1.put(s1.nextLine(), s1.nextLine());
	}
	System.out.println(h1);
	System.out.println(" Enter thed deleted product id");
	Scanner s2 = new Scanner(System.in);
	String  id = s2.next();
	  h1.remove(id);
	  System.out.println(h1);
	  
	
	}*/
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Hashtable<String,String> hm=new Hashtable<String,String>();
		System.out.println("enter the product id and name:");
		for(int i=0;i<3;i++)
		{
		hm.put(sc.next(),sc.next());
		}
		System.out.println("the product list is:");
		System.out.println(hm);
		System.out.println("enter the product id to be removed:");
		String id = sc.next();
		hm.remove(id);
		System.out.println("item removed");
		System.out.println("the product list is:");
		System.out.println(hm.toString());
		System.out.println("enter the product id to be searched:");
		String sid=sc.next();
		if(hm.containsKey(sid))
		{
			System.out.println(hm.get(sid));
		}
		else {
			System.out.println("do not exist");
		}
	}
}
