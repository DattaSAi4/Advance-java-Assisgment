package problem_statement_5_1;

public class String_manupulations {
	
	static String s1;
	public static void main(String[] args)
	{
		 s1 = "Java is Simple";
		        System.out.println("The Given is String is: "+s1);
		     String uppercas = s1.toUpperCase();
		     System.out.println("The string should be display in uppercase: " +uppercas);
		     String lowercas = s1.toLowerCase();
		     System.out.println("The string should be display in lowercase: " +lowercas);	
		                   reverse();
		               System.out.println("The length of the String: " +s1.length());
		                  
	}
	
	public static void reverse()
	{
		String rev =" ";
		for(int i=s1.length()-1; i>0 ;i--) 
		{
			 rev = rev+s1.charAt(i);
		}
		System.out.println("the reveres of the string " +rev);
	}
	

}
